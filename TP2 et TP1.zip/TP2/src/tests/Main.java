package tests;

import collection.*;

/*
 * NOTE D'UTILISATION DU PROGRAMME DE TEST :
 * 
 * - faites les exercices dans l'ordre
 * 
 * - quand un exercice est fait décommentez le code de test correspondant dans la fonction main
 *     
 * - quand la trace d'exécution coïncide avec celle indiquée en commentaire,
 *   vous pouvez passer à l'exercice suivant
 */

class Main {

	public static void main(String[] args) {

		System.out.println("---- Exercices 1 et 2 : constructeur, toString, size, contains et add ----\n");
	
		TabEnsemble e = new TabEnsemble();
		System.out.println("Ensemble initial : "); affiche(e, 2, 5, 8, 10);
		for (int i = 0; i < 6; i++) e.add(i);
		System.out.println("\nAjout de 0, 1, 2, 3, 4 et 5 : "); affiche(e, 2, 5, 8, 10);
		for (int i = 3; i < 9; i++) e.add(i);
		System.out.println("\nAjout de 3, 4, 5, 6, 7 et 8 : "); affiche(e, 2, 5, 8, 10);
		
		System.out.println("\n---- Exercice 3 : remove ----\n");
	
		e = new TabEnsemble();
		for (int i = 0; i < 7; i++) e.add(i);
		System.out.println("Ensemble initial : "); affiche(e, 6, 3, 0);
		e.remove(6);
		System.out.println("\nSuppression de 6 : "); affiche(e, 6, 3, 0);
		e.remove(3);
		System.out.println("\nSuppression de 3 : "); affiche(e, 6, 3, 0);
		e.remove(3);
		System.out.println("\nSuppression de 3 : "); affiche(e, 6, 3, 0);
		e.remove(0);
		System.out.println("\nSuppression de 0 : "); affiche(e, 6, 3, 0);
	
		System.out.println("\n---- Exercice 4 : itérateurs ----\n");
/*		
		e = new TabEnsemble();
		for (int i = 0; i < 7; i++) e.add(i);
		System.out.println("Ensemble initial : "); affiche(e);
		System.out.print("\nParcours par itérateur : ");
		for (Iterateur it = e.getIterateur(); it.hasNext();) System.out.print(it.next() + " ");
		System.out.println(); affiche(e);
		System.out.print("\nSuppression des nombres pairs : ");
		for (Iterateur it = e.getIterateur(); it.hasNext();) {
			int n = (int) (it.next()); System.out.print(n);
			if (n % 2 == 0) { System.out.print("[X] "); it.remove(); }
			else System.out.print(" ");
		}
		System.out.println(); affiche(e);
*/		
	}

	// ******************************* FONCTION D'AFFICHAGE

	static void affiche(TabEnsemble e, Object... t) {
		String s1 = e.toStringInterne();
		String s2 = "toString() : \"" + e.toString() + "\" - size() : " + e.size();
		String ok = "", ko = "";
		for (Object o : t)
			if (e.contains(o)) ok += " " + o;
			else               ko += " " + o;
		String s3 = (ok.isEmpty() ? "" : "contient :" + ok);
		String s4 = (ko.isEmpty() ? "" : "ne contient pas :" + ko);
		System.out.println("-> " + s1 + "\n-> " + s2 + (s3.isEmpty() ? "" : "\n-> " + s3) + (s4.isEmpty() ? "" : "\n-> " + s4));
	}

}

/*

---- Exercices 1 et 2 : constructeur, toString, size, contains et add ----

Ensemble initial : 
-> tab : [null, null, null, null, null] - prochainIndice : 0
-> toString() : "[ ]" - size() : 0
-> ne contient pas : 2 5 8 10

Ajout de 0, 1, 2, 3, 4 et 5 : 
-> tab : [0, 1, 2, 3, 4, 5, null, null, null, null] - prochainIndice : 6
-> toString() : "[ 0 1 2 3 4 5 ]" - size() : 6
-> contient : 2 5
-> ne contient pas : 8 10

Ajout de 3, 4, 5, 6, 7 et 8 : 
-> tab : [0, 1, 2, 3, 4, 5, 6, 7, 8, null] - prochainIndice : 9
-> toString() : "[ 0 1 2 3 4 5 6 7 8 ]" - size() : 9
-> contient : 2 5 8
-> ne contient pas : 10

---- Exercice 3 : remove ----

Ensemble initial : 
-> tab : [0, 1, 2, 3, 4, 5, 6, null, null, null] - prochainIndice : 7
-> toString() : "[ 0 1 2 3 4 5 6 ]" - size() : 7
-> contient : 6 3 0

Suppression de 6 : 
-> tab : [0, 1, 2, 3, 4, 5, 6, null, null, null] - prochainIndice : 6
-> toString() : "[ 0 1 2 3 4 5 ]" - size() : 6
-> contient : 3 0
-> ne contient pas : 6

Suppression de 3 : 
-> tab : [0, 1, 2, 5, 4, 5, 6, null, null, null] - prochainIndice : 5
-> toString() : "[ 0 1 2 5 4 ]" - size() : 5
-> contient : 0
-> ne contient pas : 6 3

Suppression de 3 : 
-> tab : [0, 1, 2, 5, 4, 5, 6, null, null, null] - prochainIndice : 5
-> toString() : "[ 0 1 2 5 4 ]" - size() : 5
-> contient : 0
-> ne contient pas : 6 3

Suppression de 0 : 
-> tab : [4, 1, 2, 5, 4] - prochainIndice : 4
-> toString() : "[ 4 1 2 5 ]" - size() : 4
-> ne contient pas : 6 3 0

---- Exercice 4 : itérateurs ----

Ensemble initial : 
-> tab : [0, 1, 2, 3, 4, 5, 6, null, null, null] - prochainIndice : 7
-> toString() : "[ 0 1 2 3 4 5 6 ]" - size() : 7

Parcours par itérateur : 0 1 2 3 4 5 6 
-> tab : [0, 1, 2, 3, 4, 5, 6, null, null, null] - prochainIndice : 7
-> toString() : "[ 0 1 2 3 4 5 6 ]" - size() : 7

Suppression des nombres pairs : 0[X] 6[X] 5 1 2[X] 4[X] 3 
-> tab : [5, 1, 3, 3, 4] - prochainIndice : 3
-> toString() : "[ 5 1 3 ]" - size() : 3

*/

