package collection;

import java.util.Arrays;
import java.util.Iterator;

/**
 * Représente un ensemble d'objets quelconques grâce à un tableau.
 * <p>
 * 
 * Les éléments de l'ensemble sont stockés dans un tableau réalloué par blocs.
 * Quand le tableau est plein, il est réalloué avec n cases en plus. Ces n cases
 * constituent un bloc.
 * <P>
 * 
 * De même, quand les cases libres du tableau constituent un bloc entier, le
 * tableau est réalloué avec un bloc de cases en moins.
 */

public class TabEnsemble implements Ensemble {

	// ******************************* ATTRIBUTS
	
	/**
	 * Constante représentant la taille d'un bloc d'allocation.
	 */
	protected static final int TAILLEBLOC = 5;

	/**
	 * Tableau stockant les éléments de l'ensemble.
	 */
	protected Object[] tab;

	/**
	 * Prochain indice d'écriture dans le tableau tab.
	 */
	protected int prochainIndice;

	// ******************************* CONSTRUCTEUR, TOSTRING et TOSTRINGINTERNE

	/**
	 * Initialise un ensemble vide en créant un tableau de la taille d'un bloc.
	 */
	public TabEnsemble() {
		this.tab = new Object[TAILLEBLOC];
		prochainIndice=0;
		
	}
	
	@Override
	public String toString() {
		String text= "[ ";
		for (int i = 0; i <= prochainIndice-1; i++) {
			text+= tab[i]+" ";
		}
		text+="]";
		

		return text; // <- TODO résultat à adapter

	}
	
	/**
	 * Représentation interne d'objet TabEnsemble.
	 * 
	 * @return représentation du tableau complet et du prochain indice
	 */
	public String toStringInterne() {
		return "tab : " + Arrays.toString(this.tab) + " - prochainIndice : " + this.prochainIndice;
	}
	
	// ******************************* MÉTHODES DE L'INTERFACE ENSEMBLE

	/**
	 * Indique le nombre d'éléments dans l'ensemble.
	 * 
	 * @return cardinal de l'ensemble
	 */
	@Override
	public int size() {
		return prochainIndice-1; // <- TODO résultat à adapter

	}

	/**
	 * Indique si un objet est présent (selon equals) dans l'ensemble.
	 * 
	 * @param o référence de l'objet recherché
	 * @return vrai ou faux selon que l'objet est présent ou non
	 */
	@Override
	public boolean contains(Object o) {
		for (int i = 0; i <= prochainIndice-1; i++) {
			if(tab[i].equals(o)) {
				return true;
			}
		}

		return false; // <- TODO résultat à adapter

	}
	
	/**
	 * Ajoute un objet à l'ensemble, seulement si la référence fournie n'est pas
	 * null et si l'objet n'est pas déjà présent (selon equals).
	 * 
	 * @param o référence de l'objet à ajouter dans l'ensemble
	 */
	@Override
	public void add(Object o) {
		if(o==null)
			return;
		if(contains(o))
			return;
		
		tab[prochainIndice]=o;
		prochainIndice++;
		
		//ajout de taillebloc en taille du tableau
		if (prochainIndice>=tab.length){
			Object tab2[]=tab;
			tab = new Object[TAILLEBLOC*(tab.length/TAILLEBLOC)+TAILLEBLOC];
			for (int i = 0; i < tab2.length; i++) {
				tab[i]=tab2[i];
			}
		}

	}

	/**
	 * Fonction utilitaire de suppression d'élément dans le tableau : retire un
	 * objet à un certain indice valide du tableau, comble le trou, et réalloue le
	 * tableau au besoin.
	 * 
	 * @param i indice (valide) de l'objet à retirer de l'ensemble
	 */
	private void remove(int i) {
		if (i==prochainIndice) {
			tab[i]=null;
			return;
		}
		for (int j = i; j <= prochainIndice-1; j++) {
			tab[j]=tab[j+1];
		}
		
		
		prochainIndice--;
		
		if(tab.length-prochainIndice>=6) {
			Object tab2[]=tab;
			tab = new Object[TAILLEBLOC*(tab.length/TAILLEBLOC)-TAILLEBLOC];
			for (int k = 0; k <= prochainIndice-1; k++){
				tab[k]=tab2[k];
			}
		}
	}

	/**
	 * Retire un objet de l'ensemble, seulement si la référence fournie désigne un
	 * objet effectivement présent (selon equals).
	 * 
	 * @param o référence de l'objet à retirer de l'ensemble
	 */
	@Override
	public void remove(Object o) {
		if(!contains(o)) {
			return;
		}
		for (int i = 0; i <= prochainIndice-1; i++) {
			if(tab[i].equals(o)) {
				remove(i);
				return;
			}
				
		}

	}

	/**
	 * Renvoie un itérateur positionné sur l'ensemble.
	 * 
	 * @return nouvel itérateur
	 */
	@Override
	public Iterateur getIterateur() {

		// TODO EXERCICE 4 : à compléter...

		return null; // <- TODO résultat à adapter

	}

	// ******************************* CLASSE INTERNE

	/**
	 * Représente un itérateur sur un ensemble de type TabEnsemble.
	 * <p>
	 * 
	 * L'itérateur est matérialisé par l'indice du prochain élément à lire dans le
	 * tableau.
	 */
	class TabEnsembleIterateur implements Iterateur {

		/**
		 * Indice du prochain élément à lire dans l'ordre de parcours de l'itérateur.
		 */
		private int next;

		/**
		 * Indique si la suppression par remove est possible ou non.
		 */
		private boolean removePossible;

		/**
		 * Initialise un itérateur avec comme premier élément à lire l'élément d'indice
		 * 0.
		 */
		public TabEnsembleIterateur() {
			this.next = 0;
			this.removePossible = false;
		}

		/**
		 * Indique si l'itérateur peut encore progresser dans son parcours des éléments
		 * de l'ensemble.
		 * 
		 * @return true s'il existe un prochain élément dans l'ordre de parcours, false
		 *         sinon
		 */
		@Override
		public boolean hasNext() {

			// TODO EXERCICE 4 : à compléter...

			return false; // <- TODO résultat à adapter

		}

		/**
		 * Revoie le prochain élément dans l'ordre de parcours et déplace l'itérateur.
		 * 
		 * @return le prochain élément dans l'ordre de parcours s'il existe, null sinon
		 */
		@Override
		public Object next() {

			// TODO EXERCICE 4 : à compléter...

			return null; // <- TODO résultat à adapter

		}

		/**
		 * Tente de supprimer le dernier élément renvoyé par next.
		 * <p>
		 * 
		 * Il n'est possible de supprimer cet élément que si next a été appelé au
		 * préalable, que le résultat n'était pas null, et que remove n'a pas déjà été
		 * appelé depuis.
		 * 
		 * @return booléen indiquant si la suppression a été faite
		 */
		@Override
		public boolean remove() {

			// TODO EXERCICE 4 : à compléter...

			return false; // <- TODO résultat à adapter

		}

	}

}
