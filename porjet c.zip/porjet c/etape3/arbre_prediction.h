#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../etape1/sequence.h"
#include "../etape2/tab_dynamique.h"


// Structure d'un nœud d'arbre de prédiction
typedef struct Arbre {
    char *word; // Mot
    int occurrences; // Nombre d'occurrences
    tab_dynamic *children; // Tableau dynamique des fils
} Arbre;

Arbre * create_arbre(const char * word);
Arbre *search_arbre(Arbre *arbre,struct strhash_table *hashtable);
void add_arbre(Arbre *parent, const char *word);
const char *max_arbre(Arbre *arbre);