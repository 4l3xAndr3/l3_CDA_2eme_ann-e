#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "arbre_prediction.h"



int main(){

    //initilisation des test 
    Arbre *parent;
    Arbre *children;
    parent=create_arbre("");
    const char * word1= "hello";
    const char * word2= "world";
    const char * word3= "!";

    //test create_arbre
    assert(!strcmp(parent->word,""));
    assert(parent->occurrences==0);
    assert(parent->children==NULL);

    //test search_arbre
        //test de l'ajout si pas trouve
        search_arbre(parent);
        assert(search_tab(parent->children,word1)!=-1);
        //test du search
        children=search_arbre(parent);
        assert(!strcmp(parent->word,children->word)!=-1);

    //test add_arbre
        //test de l'augmentation de occurence 
        add_arbre(parent,word1);
        children=search_arbre(parent);
        assert(children->occurrences==2);
        //test de la creation d'un nouveaux
        add_arbre(parent,word2);
        children=search_arbre(parent);
        assert(children->occurrences==1);
    //test max_arbre
        children=search_arbre(parent);
        children=search_arbre(children);
        children=search_arbre(children);
        assert(max_arbre(parent)==3);

    printf("Tous les tests ont réussi !\n");
    return 0;   
}