#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "arbre_prediction.h"
#include "../etape1/hash.h"

int main(){

    //initilisation des test 
    Arbre *parent;
    Arbre *children;
    parent=create_arbre("");
    char * word1= "hello";
    char * word2= "world";
    char * word3= "!";
    
    struct strhash_table *hashtable = strhash_create(Lg_N_gramme);
    sequence_initialize(hashtable);
    sequence_addWord(word1, hashtable);
    sequence_progress();
    sequence_addWord(word2, hashtable);
    sequence_progress();
    sequence_addWord(word3, hashtable);
    sequence_progress();
    
    
    //test create_arbre
    assert(!strcmp(parent->word,""));
    assert(parent->occurrences==1);


    //test search_arbre
        //test de l'ajout si pas trouve
        search_arbre(parent,hashtable);
        children = parent->children->data[0];
        assert(!strcmp(word1,children->word));
        //test du search
        children=search_arbre(parent,hashtable);
        assert(!strcmp(word1,children->word));

    //test add_arbre
        //test de l'augmentation de occurence 
        add_arbre(parent,word1);
        children = parent->children->data[0];
        assert(children->occurrences==2);
        //test de la creation d'un nouveaux
        add_arbre(parent,word2);
        children=search_arbre(parent,hashtable);
        assert(children->occurrences==1);


    //test max_arbre
        assert(strcmp(max_arbre(parent),word3));

    printf("Tous les tests ont réussi !\n");
    return 0;   
}