#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sequence.h"
#include "hash.h"

// Variables globales statiques
static char *circularBuffer[Lg_N_gramme];
static int currentIndex = 0;
static struct strhash_table *hashTable;
static int iteratorIndex = 0;


void sequence_initialize(struct strhash_table *ht) {
    hashTable = ht;
    for (int i = 0; i < Lg_N_gramme; i++) {
        circularBuffer[i] = "";
    }
    currentIndex = 0;
}


void sequence_itStart(void) {
    iteratorIndex = 0;
}


const char *sequence_itNext(void) {
    if (iteratorIndex >= Lg_N_gramme) {
        return NULL;
    }
    const char *word = circularBuffer[(currentIndex + iteratorIndex) % Lg_N_gramme];
    iteratorIndex++;
    return word;
}


int sequence_itHasNext(void) {
    return iteratorIndex < Lg_N_gramme;
}


void sequence_addWord(const char *word, struct strhash_table *ht) {
    char *addedWord = strhash_wordAdd(ht, word);
    circularBuffer[(currentIndex + Lg_N_gramme) % Lg_N_gramme] = addedWord;
}


const char *sequence_nextWord(void) {
    return circularBuffer[(currentIndex + Lg_N_gramme) % Lg_N_gramme];
}


void sequence_progress(void) {
    currentIndex = (currentIndex + 1) % Lg_N_gramme;
}


void sequence_print(void) {
    for (int i = 0; i < Lg_N_gramme; i++) {
        if (circularBuffer[(currentIndex + i) % Lg_N_gramme] != NULL) {
            printf("%s", circularBuffer[(currentIndex + i) % Lg_N_gramme]);
        } else {
            printf("<vide>");
        }
        if (i < Lg_N_gramme - 1) {
            printf(" / ");
        }
    }
    printf("\n");
}


char *sequence_printInTab(void) {
    static char buffer[256];
    buffer[0] = '\0';
    for (int i = 0; i < Lg_N_gramme; i++) {
        if (circularBuffer[(currentIndex + i) % Lg_N_gramme] != NULL) {
            strcat(buffer, circularBuffer[(currentIndex + i) % Lg_N_gramme]);
        } else {
            strcat(buffer, "");
        }
        if (i < Lg_N_gramme - 1) {
            strcat(buffer, " / ");
        }
    }
    return buffer;
}