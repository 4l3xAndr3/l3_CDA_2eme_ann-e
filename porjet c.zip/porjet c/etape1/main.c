#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h> // Include assert for condition checking
#include "sequence.h"
#include "hash.h"

int main() {
    struct strhash_table *ht = strhash_create(Lg_N_gramme);

    // Initialisation
    sequence_initialize(ht);
    sequence_itStart();

    // Ajouter des mots
    sequence_addWord("mot1", ht);
    assert(strcmp(sequence_nextWord(), "mot1") == 0);
    sequence_progress();
    sequence_addWord("mot2", ht);
    assert(strcmp(sequence_nextWord(), "mot2") == 0);
    sequence_progress();
    sequence_addWord("mot3", ht);
    assert(strcmp(sequence_nextWord(), "mot3") == 0);
    sequence_progress();
    // Vérifier le contenu du N-gramme
    sequence_itStart();
    assert(strcmp(sequence_itNext(), "mot1") == 0);
    assert(strcmp(sequence_itNext(), "mot2") == 0);
    assert(strcmp(sequence_itNext(), "mot3") == 0);
    assert(sequence_itHasNext() == 0); // Plus d'éléments à itérer

    // Avancer le N-gramme
    sequence_addWord("mot4", ht);
    sequence_progress();

    sequence_itStart();
    assert(strcmp(sequence_itNext(), "mot2") == 0); // "mot1" est éjecté
    assert(strcmp(sequence_itNext(), "mot3") == 0);
    assert(strcmp(sequence_itNext(), "mot4") == 0);

    // Vérification d'affichage
    printf("N-gramme actuel : ");
    sequence_print(); // Doit afficher "mot2 / mot3 / mot4"

    // Test de la fonction sequence_printInTab
    assert(strcmp(sequence_printInTab(), "mot2 / mot3 / mot4") == 0);

    // Ajout d'un mot déjà existant
    sequence_addWord("mot3", ht);
    sequence_progress();
    assert(strcmp(sequence_nextWord(), "mot3") == 0);

    // Libérer les ressources
    strhash_free(ht);

    printf("Tous les tests ont réussi !\n");
}
